# Token-optimization kit for Website-AI-engineering

Extract `token-kit.zip` into your repository root: every path in it is a repo path, except this folder, `_token-kit/`, which holds the install sheet and two merge helpers (delete it when done). The strategy and reasoning are in the Claude Doc "Claude Code token strategy" (https://claude.ai/artifact/7J5NjAYVZcPgimMTsfaCBL).

On Windows (PowerShell): `Expand-Archive token-kit.zip -DestinationPath . -Force` from the repo root. Files that exist are overwritten: `CLAUDE.md`, `PROJECT_STATE.md`, `.claude/settings.json`, `playwright.config.ts`, `e2e/global-setup.ts`. Commit or stash first so you can diff.

## Files

| Path | Action | What it does |
|---|---|---|
| `CLAUDE.md` | replace | Imports the (now small) `PROJECT_STATE.md`, adds the verification ladder, spec map and tool/token discipline; UI and content rules moved to path-scoped rules |
| `.claude/rules/ui.md`, `.claude/rules/content.md` | new | Former CLAUDE.md §7–9 and §12; load only when Claude touches matching files |
| `.claude/agents/e2e-runner.md` | new | Subagent that runs the gate / e2e investigations in its own context and returns ≤ 25 lines |
| `.claude/settings.json` | replace | Your original allow/deny lists unchanged, plus: agent commands allowed, Read denied on build output, `BASH_MAX_OUTPUT_LENGTH`, three hooks |
| `scripts/agent/gate.mjs` | new | `agent:check` / `agent:e2e` / `agent:gate`: same checks, one line per passing step, capped excerpt per failure, full logs in `.agent-logs/` |
| `scripts/agent/mutate.mjs`, `scripts/agent/mutations/example.json` | new | Scripted "prove the gate" mutations with automatic restore |
| `scripts/hooks/guard-bash.mjs` | new | Blocks repo-wide shell searches, raw test/build commands, `npx`, hand-started servers, `cat` of large files; tells Claude what to run instead |
| `scripts/hooks/guard-read.mjs` | new | Blocks whole-file Read of text files > 40 KB (ranged reads pass) |
| `scripts/hooks/state-size.mjs` | new | Warns Claude when `PROJECT_STATE.md` passes 8 KB; also `pnpm state:check` |
| `playwright.config.ts` | replace | Agent reporter (dot + JSON) when `AGENT_E2E=1`; `E2E_SERVERS=prod|dev|all` starts only the needed servers. Humans and CI behave exactly as before |
| `e2e/global-setup.ts` | replace | Skips the dev warm-up on production-only runs |
| `PROJECT_STATE.md` | replace | 128 KB → 4 KB. Nothing deleted: history moved to `docs/state/` |
| `docs/state/DECISIONS.md`, `MILESTONES.md`, `tasks/P*.md`, `tasks/general.md` | new | Your old §4, §3 and §8, split mechanically and verbatim |

## Merges (by hand, 2 minutes)

1. **package.json → scripts**: add the five entries in `_token-kit/package.scripts.json`.
2. **.gitignore**: append `_token-kit/gitignore.append` (`/.agent-logs/`).
3. **eslint.config.mjs → globalIgnores**: add `".agent-logs/**"` (ESLint does not read .gitignore; Prettier 3 does).
4. **knip.json**: add `"scripts/hooks/*.mjs"` to `entry` (the hooks are referenced from `.claude/settings.json`, which knip does not read).
5. Run `pnpm format` once so Prettier owns the new `.mjs`/`.ts` files, then `pnpm verify` and `pnpm test:e2e` yourself to confirm nothing changed for humans/CI.

## Notes

- The scripts were tested in a sandbox project (Node 22, Vitest 5.1, Playwright 1.63, Chromium): pass/fail detection, excerpts, `--last-failed`, prod/dev server selection, mutation kill/survive/restore and every hook rule. They were **not** run against your real repo, which I don't have, so the first `pnpm agent:gate` on your machine is the real test.
- Cross-platform: the scripts use Node built-ins only, normalise every path to forward slashes in their output, accept `e2e\\home.spec.ts` as well as `e2e/home.spec.ts`, quote arguments for cmd.exe on Windows and /bin/sh elsewhere, and resolve the repo root from the script's own location.
- Windows: hooks run as `node "$CLAUDE_PROJECT_DIR/scripts/hooks/…"`. If your Claude Code build runs hooks without a POSIX shell and the variable doesn't expand, change them to `node scripts/hooks/…` (hooks run from the project root).
- Override for one command when you really want raw output: tell Claude to append `# agent-allow`.
- CLAUDE.md §10 says Claude must not change `.claude/settings.json` without asking: copy that file in yourself.
